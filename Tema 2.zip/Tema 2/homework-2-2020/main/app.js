function addTokens(input, tokens){
    if(typeof input!=="string")  //verificare ca input sa fie de tip string
    {
        throw new Error("Invalid input");
    }
    if(input.length < 6) //verificare ca input sa fie mai mare de 6 caractere
    {
        throw new Error("Input should have at least 6 characters");
    }
    if(Array.isArray(tokens)) //verificam daca este vector
    {
        tokens.forEach((e)=>
        {
            if(typeof e.tokenName!="string")  //verificare daca se respecta structura {tokenName: string}
            {
                throw new Error("Invalid array format");
            }
        });
    }
    if(!(input.includes("..."))) //verificare daca input contine "..."
    {
        return input;
    }
    else{
        var nou;
        tokens.forEach((e) =>
            nou = input.replace("...", "${" + e.tokenName + "}")  //daca input contine "..." se face inlocuirea
        );
        return nou;
    }
}

const app = {
    addTokens: addTokens
}

module.exports = app;